function bgchange(x){
  x.style.background="Blue";
}

function bgnormal(x){
    x.style.background="rgba(231, 202, 36, 0.856)";
}
