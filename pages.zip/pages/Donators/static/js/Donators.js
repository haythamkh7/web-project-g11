
function textchange(x){
    x.style.color="rgba(231, 202, 36, 0.856)";
}

function textnormal(x){
    x.style.color="black";
}