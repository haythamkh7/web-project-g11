function bgchange(x){
  x.style.background="Blue";
}

function bgchange4(x){
    x.style.background="Blue";
}
function bgchange5(x){
    x.style.background="red";
}
function bgnormal5(x){
    x.style.background="#170b80e0";
}
function bgnormal(x){
    x.style.background="rgba(231, 202, 36, 0.856)";
}

function bgnormal4(x){
    x.style.background="rgba(214, 68, 42, 0.842)";
}


function textchange(x){
    x.style.color="rgba(231, 202, 36, 0.856)";
}

function textnormal(x){
    x.style.color="black";
}
function setnewimg1(){
document.getElementById("img1").src ="img4";
}